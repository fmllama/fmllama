<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");
require("includes/reisetagebuch.inc.php");

$msg = "";

session_start();

if(count($_POST)>0) {
	$sql = "
		SELECT COUNT(*) AS cnt
		FROM tbl_votings
		WHERE(
			FIDReise=" . $_POST["IDReise"] . " AND
			FIDUser=" . $_POST["IDUser"] . "
		)
	";
	$q = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	$data = $q->fetch_object();
	if($data->cnt==0) {
		$sql = "
			INSERT INTO tbl_votings
				(FIDUser, FIDReise, FIDBewertung)
			VALUES (
				" . $_POST["IDUser"] . ",
				" . $_POST["IDReise"] . ",
				" . $_POST["IDSkala"] . "
			)
		";
		$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
		$msg = '<p class="success">Vielen Dank für Ihre Bewertung.</p>';
	}
	else {
		$msg = '<p class="error">Sie haben diese Reise bereits bewertet.</p>';
	}
}
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Reisetagebuch</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/reisetagebuch.css">
</head>

<body>
	<?php include("parts/navigation.part.html"); ?>
	<?php
	echo($msg);
	echo(reisen_show(null,false,true));
	?>
</body>
</html>