<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");
require("includes/reisetagebuch.inc.php");

$msg = "";

if(count($_POST)>0) {
	switch(true) {
		case isset($_POST["REG"]):
			$sql = "
				SELECT COUNT(*) AS cnt
				FROM tbl_user
				WHERE(
					Emailadresse='" . $_POST["E"] . "'
				)
			";
			$q = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			$data = $q->fetch_object();
			if($data->cnt==0) {
				if($_POST["P0"]==$_POST["P1"] && strlen($_POST["P0"])>0) {
					$sql = "
						INSERT INTO tbl_user
							(Emailadresse, Passwort, Vorname, Nachname, Beschreibung)
						VALUES (
							'" . $_POST["E"] . "',
							'" . password_hash($_POST["P0"], PASSWORD_DEFAULT) . "',
							" . check_string($_POST["VN"]) . ",
							" . check_string($_POST["NN"]) . ",
							" . check_string($_POST["B"]) . "
						)
					";
					ta($sql);
					$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
					
					login($conn->insert_id);
				}
				else {
					$msg = '<p class="error">Das Passwort entspricht nicht den Anforderungen.</p>';
				}
			}
			else {
				$msg = '<p class="error">Diese Emailadresse ist bereits registriert.</p>';
			}
			break;
			
		case isset($_POST["LOG"]):
			$sql = "
				SELECT
					IDUser, Passwort
				FROM tbl_user
				WHERE(
					Emailadresse='" . $_POST["E"] . "'
				)
			";
			$q = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			$data = $q->fetch_object();
			if(password_verify($_POST["P"],$data->Passwort)) {
				login($data->IDUser);
			}
			else {
				$msg = '<p class="error">Die eingegebenen Daten waren nicht korrekt.</p>';
			}
			break;

	}
}
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Reisetagebuch</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/reisetagebuch.css">
</head>

<body>
	<?php include("parts/navigation.part.html"); ?>
	<?php echo($msg); ?>
	<div id="Grid">
		<p>Registrierung:</p>
		<form method="post">
			<fieldset>
				<legend>Pflichtangaben</legend>
				<label data-required>
					Emailadresse:
					<input type="email" name="E" required>
				</label>
				<label data-required>
					Passwort (mind. acht Zeichen):
					<input type="password" name="P0" required>
					<input type="password" name="P1" required placeholder="Passwort wiederholen">
				</label>
				<label data-required>
					Vorname:
					<input type="text" name="VN" required>
				</label>
			</fieldset>
			<fieldset>
				<legend>optionale Angaben</legend>
				<label>
					Nachname:
					<input type="text" name="NN">
				</label>
				<label>
					eigene Beschreibung:
					<textarea name="B"></textarea>
				</label>
			</fieldset>
			<input type="submit" name="REG" value="registrieren">
		</form>
		<p>Login:</p>
		<form method="post">
			<label data-required>
				Emailadresse:
				<input type="email" name="E" required>
			</label>
			<label data-required>
				Passwort:
				<input type="password" name="P" required>
			</label>
			<input type="submit" name="LOG" value="einloggen">
		</form>
	</div>
</body>
</html>