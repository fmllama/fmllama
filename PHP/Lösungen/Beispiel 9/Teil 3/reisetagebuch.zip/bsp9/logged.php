<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");
require("includes/logged.inc.php");
require("includes/reisetagebuch.inc.php");

$msg = "";

if(count($_POST)>0) {
	switch(true) {
		case isset($_POST["LOGOUT"]):
			$_SESSION = [];
			if(ini_get("session.use_cookies")) {
				$params = session_get_cookie_params();
				setcookie(session_name(), '', time()-86400, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
			}
			session_destroy();
			header("Location: login_register.php");
			break;
			
		case isset($_POST["ReiseNeu"]):
			$sql = "
				INSERT INTO tbl_reisen
					(Titel, Beschreibung, FIDUser)
				VALUES (
					'" . $_POST["Titel"] . "',
					" . check_string($_POST["Beschreibung"]) . ",
					" . $_SESSION["IDUser"] . "
				)
			";
			$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			break;
			
		case isset($_POST["AbschnittNeu"]):
			$sql = "
				INSERT INTO tbl_abschnitte
					(FIDReise,FIDAbschnitt,Titel,Beschreibung,von,bis,FIDStaat)
				VALUES (
					" . $_POST["IDReise"] . ",
					" . check_numeric($_POST["IDAbschnitt"]) . ",
					'" . $_POST["Titel"] . "',
					" . check_string($_POST["Beschreibung"]) . ",
					'" . $_POST["von"] . "',
					'" . $_POST["bis"] . "',
					" . $_POST["IDStaat"] . "
				)
			";
			$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			break;
	}
}

function abschnitt_neu(int $idReise, ?int $idAbschnitt=null):string {
	$r = '
		<form method="post" class="' . (!is_null($idAbschnitt) ? "hide" : "") . '">
			<legend>Neuer Abschnitt</legend>
			<input type="hidden" name="IDReise" value="' . $idReise . '">
			<input type="hidden" name="IDAbschnitt" value="' . $idAbschnitt . '"
			<label data-required">
				Titel:
				<input type="text" name="Titel" required>
			</label>
			<label>
				Beschreibung:
				<textarea name="Beschreibung"></textarea>
			</label>
			<label data-required">
				von <input type="datetime-local" name="von" required class="inline">
				bis <input type="datetime-local" name="bis" required class="inline">
			</label>
			<label data-required>
				Staat:
				' . staaten_show() . '
			</label>
			<input type="submit" name="AbschnittNeu" value="speichern">
		</form>
	';
	return $r;
}
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Reisetagebuch</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/reisetagebuch.css">
	<script src="js/jquery-3.7.1.min.js"></script>
</head>

<body>
	<?php include("parts/navigation.part.html"); ?>
	<?php echo($msg); ?>
	<form method="post">
		<input type="submit" name="LOGOUT" value="ausloggen">
	</form>
	<form method="post">
		<fieldset>
			<legend>neue Reise anlegen</legend>
			<label data-required>
				Titel:
				<input type="text" name="Titel" required>
			</label>
			<label>
				Beschreibung (optional):
				<textarea name="Beschreibung"></textarea>
			</label>
			<input type="submit" name="ReiseNeu" value="anlegen">
		</fieldset>
	</form>
	<h2>Meine Reisen</h2>
	<?php echo(reisen_show($_SESSION["IDUser"],true)); ?>
	
</body>
</html>