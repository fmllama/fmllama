<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");
require("includes/reisetagebuch.inc.php");

$msg = "";
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Reisetagebuch</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/reisetagebuch.css">
</head>

<body>
	<?php include("parts/navigation.part.html"); ?>
	<form method="post">
		<label>
			Vorname:
			<input type="search" name="VN">
		</label>
		<input type="submit" value="filtern">
	</form>
	<ul>
		<?php
		$sqlW = "";
		if(count($_POST)>0 && strlen($_POST["VN"])>0) {
			$sqlW = "
				WHERE (
					Vorname LIKE '%" . $_POST["VN"] . "%'
				)
			";
		}

		$sql = "
			SELECT
				*
			FROM tbl_user
			" . $sqlW . "
			ORDER BY Vorname ASC
		";
		$userliste = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
		while($user = $userliste->fetch_object()) {
			echo('
				<li>' . $user->Vorname . ' ' . $user->Nachname . ':
					<ul>
			');
			
			// ---- Reisen je User: ----
			$sql = "
				SELECT
					*,
					(
					SELECT
						AVG(tbl_skala.Wert)
					FROM tbl_votings
					INNER JOIN tbl_skala ON tbl_skala.IDSkala=tbl_votings.FIDBewertung
					WHERE(
						tbl_votings.FIDReise=tbl_reisen.IDReise
					)
				) AS bewertung,
				(
					SELECT
						MAX(Wert)
					FROM tbl_skala
				) AS maxBewertung
				FROM tbl_reisen
				WHERE(
					FIDUser=" . $user->IDUser . "
				)
			";
			$reisen = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			while($reise = $reisen->fetch_object()) {
				echo('
					<li>
						<strong>' . $reise->Titel . '</strong>
						<span class="voting">' . (is_null($reise->bewertung) ? "(noch keine Bewertungen)" : (round($reise->maxBewertung+1-$reise->bewertung,2) . '/' . $reise->maxBewertung)) . '</span><br>
						<div class="beschreibung">' . $reise->Beschreibung . '</div>
					</li>
						
				');
			}
			// ENDE Reisen je User: ----
			
			echo('
					</ul>
				</li>
			');
		}
		echo('</ul>');
		?>
	</ul>
</body>
</html>