<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");

function kategorien_show():string {
	global $conn;
	$r = '';
	
	$sql = "
		SELECT
			IDKategorie,
			Kategorie
		FROM tbl_kategorien
		ORDER BY Kategorie ASC
	";
	$kategorien = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($kategorie = $kategorien->fetch_object()) {
		$r.= '
			<label class="kat">
				<input type="checkbox" name="kategorien[]" value="' . $kategorie->IDKategorie . '">
				' . $kategorie->Kategorie . '
			</label>
		';
	}
	return $r;
}

function allergene_show():string {
	global $conn;
	$r = '';
	
	$sql = "
		SELECT
			IDAllergen,
			Kurzzeichen,
			Beschreibung
		FROM tbl_allergene
		ORDER BY Kurzzeichen ASC
	";
	$allergene = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($allergen = $allergene->fetch_object()) {
		$r.= '
			<label class="allergen">
				<input type="checkbox" name="allergene[]" value="' . $allergen->IDAllergen . '">
				' . $allergen->Kurzzeichen . ': ' . $allergen->Beschreibung . '
			</label>
		';
	}
	return $r;
}

function einheiten_show():string {
	global $conn;
	$r = '
		<select name="IDEinheit">
			<option value="0">Bitte wählen (optional)</option>
	';
	
	$sql = "
		SELECT
			IDEinheit,
			Einheit
		FROM tbl_einheiten
		ORDER BY Einheit ASC
	";
	$einheiten = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($einheit = $einheiten->fetch_object()) {
		$r.= '
			<option value="' . $einheit->IDEinheit . '">' . $einheit->Einheit . '</option>
		';
	}
	
	$r.= '</select>';
	return $r;
}

function check_numeric(string|int|float $val, bool $isFloat=false):int|float|string {
	$val = $isFloat ? floatval($val) : intval($val);
	return $val>0 ? $val : "NULL";
}

function check_string(string $val):string {
	return strlen($val)>0 ? "'" . $val . "'" : "NULL";
}

function produkte_show():string {
	global $conn;
	$r = '';
	
	$sql = "
		SELECT
			IDProdukt,
			Produkt
		FROM tbl_produkte
		ORDER BY Produkt ASC
	";
	$produkte = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($produkt = $produkte->fetch_object()) {
		$r.= '
			<label class="produkt">
				<input type="checkbox" name="produkte[]" value="' . $produkt->IDProdukt . '">
				' . $produkt->Produkt . '
			</label>
		';
	}
	return $r;
}


$msg = '';
ta($_POST);
if(count($_POST)>0) {
	switch(true) {
		case isset($_POST["btnStore"]):
			$sql = "
				INSERT INTO tbl_produkte
					(Anzahl, FIDEinheit, Produkt, Zusatztext, Anmerkungen, Preis)
				VALUES (
					" . check_numeric($_POST["Anzahl"],true) . ",
					" . check_numeric($_POST["IDEinheit"],false) . ",
					'" . $_POST["Produkt"] . "',
					" . check_string($_POST["Zusatztext"]) . ",
					" . check_string($_POST["Anmerkungen"]) . ",
					" . check_numeric($_POST["Preis"],true) . "
				)
			";
			$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			$idProdukt = $conn->insert_id;

			if(isset($_POST["kategorien"])) {
				$arr = [];
				foreach($_POST["kategorien"] as $idKategorie) {
					$arr[] = "(" . $idProdukt . "," . $idKategorie . ")";
				}
				$sql = "
					INSERT INTO tbl_produkte_kategorien
						(FIDProdukt, FIDKategorie)
					VALUES
					" . implode(", ",$arr) . "
				";
				$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			}
			if(isset($_POST["allergene"])) {
				$arr = [];
				foreach($_POST["allergene"] as $idAllergen) {
					$arr[] = "(" . $idProdukt . "," . $idAllergen . ")";
				}
				$sql = "
					INSERT INTO tbl_produkte_allergene
						(FIDProdukt, FIDAllergen)
					VALUES
					" . implode(", ",$arr) . "
				";
				$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
			}

			$msg = '<p class="success">Vielen Dank. Das Produkt mit der Kennung "' . $idProdukt . '" wurde erfolgreich angelegt.</p>';
		break;
	
	case isset($_POST["btnDelete"]) && isset($_POST["produkte"]):
		$arr = [];
		foreach($_POST["produkte"] as $idProdukt) {
			$arr[] = "IDProdukt=" . $idProdukt;
		}
	
		$sql = "
			DELETE FROM tbl_produkte
			WHRE(
				" . implode(" OR ",$arr) . "
			)
		";
		$ok = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
		$msg = '<p class="success">Die ausgewählten Produkte wurden gelöscht.</p>';
		break;
	}
}
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Speisekarte</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/speisekarte.css">
	<script>
		function del() {
			return confirm("Wollen Sie diese Produkte wirklich löschen?");
		}
	</script>
</head>

<body>
	<nav>
		<ul>
			<li><a href="index.html">Startseite</a></li>
			<li><a href="speisekarte.php">Speisekarte</a></li>
		</ul>
	</nav>
	<?php echo($msg); ?>
	<form method="post">
		<fieldset>
			<legend>Kategorien</legend>
			<?php
			echo(kategorien_show());
			?>
		</fieldset>
		<fieldset>
			<legend>Allergene</legend>
			<?php
			echo(allergene_show());
			?>
		</fieldset>
		<label>
			Anzahl:
			<input type="number" name="Anzahl" required>
		</label>
		<label>
			Einheit:
			<?php echo(einheiten_show()); ?>
		</label>
		<label data-required>
			Produktbezeichnung:
			<input type="text" name="Produkt" required>
		</label>
		<label>
			Zusatztext:
			<textarea name="Zusatztext" placeholer="zB. 'mit Sauerkraut und Semmelknödel'"></textarea>
		</label>
		<label>
			Anmerkungen:
			<textarea name="Anmerkungen" placeholder="zB. 'enthält Süßungsmittel'"></textarea>
		</label>
		<label>
			Preis:
			<input type="number" name="Preis" step="0.01">
		</label>
		<input type="submit" value="speichern" name="btnStore">
	</form>
	<p>Produkte löschen:</p>
	<form method="post" onsubmit="return del();">
		<fieldset>
			<legend>ausgewählte Produkte löschen</legend>
			<?php echo(produkte_show()); ?>
		</fieldset>
		<input type="submit" value="löschen" name="btnDelete">
	</form>
</body>
</html>