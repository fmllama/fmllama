<?php
function check_numeric(string|int|float $val, bool $isFloat=false):int|float|string {
	$val = $isFloat ? floatval($val) : intval($val);
	return $val>0 ? $val : "NULL";
}

function check_string(string $val):string {
	return strlen($val)>0 ? "'" . $val . "'" : "NULL";
}

function login(int $IDUser):void {
	session_start();
	$_SESSION["eingeloggt"] = true;
	$_SESSION["IDUser"] = $IDUser;
	header("Location: logged.php");
}

function reisen_show(?int $idUser=null, bool $includeAdd=false, bool $includeBewertungsform=false):string {
	global $conn;
	$r = "";
	
	$sqlW = !is_null($idUser) ?
		"
			WHERE(
				FIDUser=" . $idUser . "
			)
		" : "";
	
	$sql = "
		SELECT
			*,
			(
				SELECT
					AVG(tbl_skala.Wert)
				FROM tbl_votings
				INNER JOIN tbl_skala ON tbl_skala.IDSkala=tbl_votings.FIDBewertung
				WHERE(
					tbl_votings.FIDReise=tbl_reisen.IDReise
				)
			) AS bewertung,
			(
				SELECT
					MAX(Wert)
				FROM tbl_skala
			) AS maxBewertung
		FROM tbl_reisen
		" . $sqlW . "
		ORDER BY Titel ASC
	";
	$reisen = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($reise = $reisen->fetch_object()) {
		$r.='
			<article class="reisen">
				<strong>' . $reise->Titel . '</strong>
				<span class="voting">' . (is_null($reise->bewertung) ? "(noch keine Bewertungen)" : (round($reise->maxBewertung+1-$reise->bewertung,1) . '/' . $reise->maxBewertung)) . '</span><br>
				<div class="beschreibung">' . $reise->Beschreibung . '</div>
				' . abschnitte_get($reise->IDReise,null,$includeAdd) . '
				' . ($includeAdd ? abschnitt_neu($reise->IDReise) : "") . '
				' . ($includeBewertungsform && $reise->FIDUser!=$_SESSION["IDUser"] ? bewertungsform_get($reise->IDReise) : '') . '
			</article>
		';
	}
	
	return $r;
}

function abschnitte_get(int $idReise, ?int $idAbschnitt=null, bool $includeAdd=false):string {
	global $conn;
	$btn = $includeAdd ? '<button type="button" onclick="$(this).nextAll(\'form\').toggleClass(\'hide\');" class="add">+ neuer Abschnitt</button>' : '';
	$r = '<ul class="abschnitte">';

	$sql = "
		SELECT
			tbl_abschnitte.IDAbschnitt,
			tbl_abschnitte.Titel,
			tbl_abschnitte.Beschreibung,
			tbl_abschnitte.von,
			tbl_abschnitte.bis,
			tbl_staaten.Staat
		FROM tbl_abschnitte
		INNER JOIN tbl_staaten ON tbl_staaten.IDStaat=tbl_abschnitte.FIDStaat
		WHERE(
			tbl_abschnitte.FIDReise=" . $idReise . " AND
			tbl_abschnitte.FIDAbschnitt " . (is_null($idAbschnitt) ? " IS NULL" : "=" . $idAbschnitt) . "
		)
		ORDER BY tbl_abschnitte.von ASC
	";
	$abschnitte = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($abschnitt = $abschnitte->fetch_object()) {
		$r.= '
			<li>
				<div class="datum">' . date("j.n.Y, H:i",strtotime($abschnitt->von)) . ' Uhr bis ' . date("j.n.Y, H:i",strtotime($abschnitt->bis)) . ' Uhr</div>
				' . $abschnitt->Titel . '' . $btn . '
				<div class="beschreibung">' . $abschnitt->Beschreibung . '</div>
				<div class="staat">' . $abschnitt->Staat . '</div>
				' . abschnitte_get($idReise,$abschnitt->IDAbschnitt,$includeAdd) . '
				' . ($includeAdd ? abschnitt_neu($idReise,$abschnitt->IDAbschnitt) : '') . '
				
			</li>
		';
	}
	
	$r.= '</ul>';
	
	return $r;
}

function staaten_show():string {
	global $conn;
	$r = '<select name="IDStaat" data-required>';
	
	$sql = "
		SELECT
			*
		FROM tbl_staaten
		ORDER BY Staat ASC
	";
	$staaten = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($staat = $staaten->fetch_object()) {
		$r.= '<option value="' . $staat->IDStaat . '">' . $staat->Staat . '</option>';
	}
	$r.= '</select>';
	return $r;
}

function bewertungsform_get(int $idReise):string {
	global $conn;
	$r = '
		<form method="post">
			<input type="hidden" name="IDReise" value="' . $idReise . '">
			<input type="hidden" name="IDUser" value="' . $_SESSION["IDUser"] . '">
			<select name="IDSkala">
	';
	
	$sql = "
		SELECT
			*
		FROM tbl_skala
		ORDER BY Wert ASC
	";
	$werte = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($wert = $werte->fetch_object()) {
		$r.= '<option value="' . $wert->IDSkala . '">' . $wert->Bewertung . ' (' . $wert->Wert . ')</option>';
	}
	
	$r.= '
			</select>
			<input type="submit" name="BEW" value="bewerten">
		</form>
	';
	return $r;
}
?>