<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Reisetagebuch</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/reisetagebuch.css">
</head>

<body>
	<p>Bitte wählen Sie aus:</p>
	<?php include("parts/navigation.part.html"); ?>
</body>
</html>