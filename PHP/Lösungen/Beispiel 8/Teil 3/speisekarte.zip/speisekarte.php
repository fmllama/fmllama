<?php
require("includes/config.inc.php");
require("includes/common.inc.php");
require("includes/conn.inc.php");

function kategorien_show(array $allergene, int $idKategorie=null, array $hinweise=[]):array {
	global $conn;
	
	$r = '<ul class="kategorien">';
	
	$arr = [];
	$arr[] = is_null($idKategorie) ? "tbl_kategorien.FIDKategorie IS NULL" : "tbl_kategorien.FIDKategorie=" . $idKategorie;
	$arr[] = "
		(
			tbl_wochenmenue.IDWochenmenue IS NULL OR
			tbl_wochenmenue.IDWochenmenue IS NOT NULL AND
			tbl_wochenmenue.gueltigVon<=NOW() AND
			tbl_wochenmenue.gueltigBis>=NOW()
		)
	";
	
	$sql = "
		SELECT
			tbl_kategorien.IDKategorie,
			tbl_kategorien.Kategorie,
			tbl_wochenmenue.gueltigVon,
			tbl_wochenmenue.gueltigBis,
			tbl_wochenmenue.Preis
		FROM tbl_kategorien
		LEFT JOIN tbl_wochenmenue ON tbl_wochenmenue.FIDKategorie=tbl_kategorien.IDKategorie
		WHERE(
			" . implode(" AND ",$arr) . "
		)
	";

	$kats = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($kat = $kats->fetch_object()) {
		$r.= '<li><span class="kategorie">' . $kat->Kategorie;
		if(!is_null($kat->gueltigVon)) {
			$r.= ' (' . date("j.n.",strtotime($kat->gueltigVon)) . ' bis ' . date("j.n.Y",strtotime($kat->gueltigBis)) . ') – &euro; ' . $kat->Preis;
		}
		$r.= '</span>';
		
		// ---- Produkte: ----
		$ret = produkte_show($allergene,$kat->IDKategorie,!is_null($kat->gueltigVon),$hinweise);
		$hinweise = $ret[1];
		$r.= $ret[0];
		// -------------------
		
		// ---- Rekursion: ----
		$ret = kategorien_show($allergene,$kat->IDKategorie,$hinweise);
		$hinweise = $ret[1];
		$r.= $ret[0];
		// --------------------
		
		$r.= '
			</li>
		';
	}
	
	$r.= '</ul>';
	return [$r,$hinweise];
}

function produkte_show(array $allergene, int $idKategorie, bool $isWochenmenue, array $hinweise=[]):array {
	global $conn;
	
	$r = '<ul class="produkte">';
	
	$sql = "
		SELECT
			tbl_produkte.IDProdukt,
			tbl_produkte.Anzahl,
			tbl_einheiten.Einheit,
			tbl_produkte.Produkt,
			tbl_produkte.Zusatztext,
			tbl_produkte.Anmerkungen,
			tbl_produkte.Preis
		FROM tbl_produkte_kategorien
		INNER JOIN tbl_produkte ON tbl_produkte.IDProdukt=tbl_produkte_kategorien.FIDProdukt
		LEFT JOIN tbl_einheiten ON tbl_einheiten.IDEinheit=tbl_produkte.FIDEinheit
		WHERE(
			tbl_produkte_kategorien.FIDKategorie=" . $idKategorie . "
		)
		ORDER BY tbl_produkte_kategorien.Reihenfolge ASC
	";
	$produkte = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($produkt = $produkte->fetch_object()) {
		$allergenliste = allergene_get($produkt->IDProdukt);
		$show = true;
		foreach($allergenliste as $a) {
			if(in_array($a,$allergene)) {
				$show = false;
				break;
			}
		}
		
		if($show) {
			$allergeninfos = count($allergenliste)>0 ? '<span class="allergene">(' . implode(", ",$allergenliste) . ')</span>' : '';
			$r.= '
				<li>
					<span>
						' . (!is_null($produkt->Anzahl) ? $produkt->Anzahl . ' ' : '') . '
						' . (!is_null($produkt->Einheit) ? $produkt->Einheit . ' ' : '') . '
						' . $produkt->Produkt . '
						' . $allergeninfos . '
						' . (!is_null($produkt->Anmerkungen) ? '<sup>' . (count($hinweise)+1) . ')</sup>' : '') . '
					</span>
					<span class="preis">
						' . (!$isWochenmenue ? '&euro; ' . $produkt->Preis : '') . '
					</span>
				</li>
			';
			if(!is_null($produkt->Anmerkungen)) { $hinweise[] = $produkt->Anmerkungen; }
		}
	}
	
	$r.= '</ul>';
	return [$r,$hinweise];
}

function allergene_get(int $idProdukt):array {
	global $conn;
	
	$arr = [];
	$sql = "
		SELECT
			tbl_allergene.Kurzzeichen
		FROM tbl_produkte_allergene
		INNER JOIN tbl_allergene ON tbl_allergene.IDAllergen=tbl_produkte_allergene.FIDAllergen
		WHERE(
			FIDProdukt=" . $idProdukt . "
		)
	";
	$allergene = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($allergen = $allergene->fetch_object()) {
		$arr[] = $allergen->Kurzzeichen;
	}
	
	return $arr;
}

function allergeninfos_show():string {
	global $conn;
	
	$sql = "
		SELECT
			Kurzzeichen,
			Beschreibung
		FROM tbl_allergene
		ORDER BY Kurzzeichen ASC
	";
	$allergene = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($allergen = $allergene->fetch_object()) {
		$arr[] = $allergen->Kurzzeichen.'='.$allergen->Beschreibung;
	}
	return implode(", ",$arr);
}
function suessungsmittelinfos_show(array $hinweise):string {
	global $conn;
	$r = '(keine)';
	
	if(count($hinweise)>0) {
		$r = '<ul class="suessungsmittel">';
		for($i=0; $i<count($hinweise); $i++) {
			$r.= '<li><sup>' . ($i+1) . ')</sup> ' . $hinweise[$i] . '</li>';
		}
		$r.= '</ul>';
	}
	return $r;
}

function allergene_form_show(array $arr_checked=[]):string {
	global $conn;
	$r = '';
	
	$sql = "
		SELECT
			IDAllergen,
			Kurzzeichen,
			Beschreibung
		FROM tbl_allergene
		ORDER BY Kurzzeichen ASC
	";
	$allergene = $conn->query($sql) or die("Fehler in der Query: " . $conn->error . "<br>" . $sql);
	while($allergen = $allergene->fetch_object()) {
		$checked = in_array($allergen->Kurzzeichen,$arr_checked) ? "checked" : "";
		$r.= '
			<label class="allergen">
				<input type="checkbox" name="allergene[]" value="' . $allergen->Kurzzeichen . '" ' . $checked . '>
				' . $allergen->Kurzzeichen . ': ' . $allergen->Beschreibung . '
			</label>
		';
	}
	return $r;
}

if(count($_POST)==0) {
	$_POST["allergene"] = [];
}
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="UTF-8">
<title>Speisekarte</title>
	<link rel="stylesheet" href="css/common.css">
	<link rel="stylesheet" href="css/speisekarte.css">
</head>

<body>
	<nav>
		<ul>
			<li><a href="index.html">Startseite</a></li>
			<li><a href="produkteingabe.php">Eingabe von Produkten</a></li>
		</ul>
	</nav>
	<form method="post">
		<fieldset>
			<legend>Speisen mit diesen Allergenen ausschließen:</legend>
			<?php
			echo(allergene_form_show($_POST["allergene"]));
			?>
		</fieldset>
		<input type="submit" value="filtern">
	</form>
	<?php
	$ret = kategorien_show($_POST["allergene"]);
	echo($ret[0]);
	?>
	<div class="infos">
		<strong>Allergeninformationen gemäß Codex-Empfehlung:</strong>
		<?php echo(allergeninfos_show()); ?>
	</div>
	<div class="infos">
		<strong>Information über Süßungsmittel (gemäß VO des BMG vom 10.07.2014, BGBl Nr. II/175/2014):</strong>
		<?php echo(suessungsmittelinfos_show($ret[1])); ?>
	</div>
</body>
</html>