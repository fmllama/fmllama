<?php
error_reporting(E_ALL);
ini_set("display_errors",1);

define("TESTMODE",1);
define("DB",array(
	"host" => "localhost",
	"user" => "root",
	"pwd" => "",
	"db" => "db_lap_speisekarte"
));
?>